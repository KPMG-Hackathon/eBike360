$(document).ready(function () {
    $(".chat_icon").click(function (event) {
        $(".chat_box").toggleClass('active');
    });
});
$(document).ready(function () {
    const styleSet = window.WebChat.createStyleSet({
        bubbleBackground: 'rgba(0, 0, 255, .1)',
        bubbleFromUserBackground: 'rgba(0, 255, 0, .1)',
        rootHeight: '100%',
        rootWidth: '100%'
    });
    const avatarOptions = {
        botAvatarImage: '/Content/Bot/eBikeNew.png',
        botAvatarInitials: 'eB',
        userAvatarImage: '/Content/Bot/user_icon.png',
        userAvatarInitials: 'U'
    };

    window.WebChat.renderWebChat({
        directLine: window.WebChat.createDirectLine({
            secret: 'c3tw6bug1MI.55d4Rapbb2lVdXkku9DXzxbduEqy_TNcAaIj95O76N4'
        }),
        styleSet,
        styleOptions: avatarOptions
    }, document.getElementById('webchat'));

    $(document.getElementById('webchat').children[0]).css({ "background-image": "url('/Content/Bot/gilead_hackathon.png')", "border-radius": "25px", "background-size": "100%", "font-size": "medium", "font-weight": "normal", "background-color":"blanchedalmond" });
});
     // Set  the CSS rules.
   
         