# Get the connection "AzureRunAsConnection"
$connectionName = "AzureRunAsConnection"
$servicePrincipalConnection = Get-AutomationConnection -Name $connectionName

$connectionResult = Connect-AzAccount `
                           -ServicePrincipal `
                           -Tenant $servicePrincipalConnection.TenantId `
                           -ApplicationId $servicePrincipalConnection.ApplicationId `
                           -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
#Variables Declaration
$iothubname = 'IoTBikeSetup'
$resourcegroupname = 'Sentient360-East-Asia-RG'
$sku = 'F1'
$unit = 1
$location = 'eastasia'
$MinVal = 1101
$MaxVal = 8888
$MaxDevicesCount = 500
$DeviceCounter=1
$divcnt = 295



$AzIoT = Get-AzIotHub
#Create an IOT HUB named IoTBikeSetup
if ($AzIoT.Name -eq $iothubname) {
     Write-Output $iothubname "Iot Hub Exists"
     $DeviceStatus = Get-AzIotHubDevice -ResourceGroupName $resourcegroupname -IotHubName $iothubname
    $DeviceMetrics = Get-AzIotHubQuotaMetric -ResourceGroupName $resourcegroupname -Name $iothubname
    #Retrieve all the device identities 
    $Array = Get-AzIotHubDevice -ResourceGroupName $resourcegroupname -IotHubName $iothubname
    ForEach ($device in $array)
    {
         Write-Output $device.Id
        For ($i = 0; $i -lt 5; $i++)
         {
             #Sending Device to Cloud messages for every device
             Send-AzIotHubDevice2CloudMessage -ResourceGroupName $resourcegroupname -IotHubName $iothubname -DeviceId $device.Id -Message "Check tyre pressure"
         }
   }
     ForEach($metrics in  $DeviceMetrics)
     {  
         #Write-Output $metrics
         #Write-Output $metrics.CurrentValue
         if( $metrics.Name -eq "TotalDeviceCount" -AND  $metrics.MaxValue -eq "Unlimited" -AND $metrics.CurrentValue -lt 500)
         {
             Write-Output "yes"
         }
     }

}
else
{
    Write-Output "Creating new IotHub - " $iothubname

#Create new IoT Hub if not exists
    New-AzIotHub -Name $iothubname `
        -ResourceGroupName $resourcegroupname `
        -SkuName $sku `
        -Unit $unit `
        -Location $location
    Write-Output "Created IoT Hub : " $iothubname
    Start-Sleep -Seconds 180
    Write-Output $iothubname "is Activated"
    Get-AzIotHubConnectionString -ResourceGroupName $resourcegroupname -Name $iothubname
    $DeviceMetrics = Get-AzIotHubQuotaMetric -ResourceGroupName $resourcegroupname -Name $iothubname
    
 #Creting devices
   
    while($DeviceCounter -le $MaxDevicesCount)
        {
            $Random1 = Get-Random -Minimum -$MinVal -Maximum $MaxVal
            $Random2 = Get-Random -Minimum -$MinVal -Maximum $MaxVal
            $Random3 = Get-Random -Minimum -$MinVal -Maximum $MaxVal
            $DeviceID = "eBike"+$Random1+$Random2+$Random3
            $Array = Get-AzIotHubDevice -ResourceGroupName $resourcegroupname -IotHubName $iothubname
            if($Array.Id -ne $DeviceID)
                {
                    Add-AzIotHubDevice -ResourceGroupName $resourcegroupname -IotHubName $iothubname -DeviceId $DeviceID 
                    Write-Output "Device Created:" $DeviceID
                    $DeviceCounter= $DeviceCounter+1
                }
        }
    #Retrieve all the device identities 
    $Array = Get-AzIotHubDevice -ResourceGroupName $resourcegroupname -IotHubName $iothubname
    ForEach ($device in $array)
    {
         Write-Output $device.Id
        For ($i = 0; $i -lt 5; $i++)
         {
             #Sending Device to Cloud messages for every device
             Send-AzIotHubDevice2CloudMessage -ResourceGroupName $resourcegroupname -IotHubName $iothubname -DeviceId $device.Id -Message "Check tyre pressure"
         }
   }
}

